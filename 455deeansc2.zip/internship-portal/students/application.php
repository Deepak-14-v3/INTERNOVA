<?php
session_start();
require_once '../config/database.php';

// Security check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['name'];

// Fetch applications for this student with internship details and company name
$stmt = $pdo->prepare("
    SELECT applications.*, internships.title, internships.location, internships.stipend, users.name as company_name 
    FROM applications 
    JOIN internships ON applications.internship_id = internships.id 
    JOIN users ON internships.company_id = users.id 
    WHERE applications.student_id = ? 
    ORDER BY applications.created_at DESC
");
$stmt->execute([$student_id]);
$applications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Applications - INTERNOVA</title>
    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
            --success: #22C55E;
            --warning: #F59E0B;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            padding: 2rem;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(37, 99, 235, 0.15) 0%, transparent 40%);
            background-attachment: fixed;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
        }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover, .nav-links a.active {
            color: var(--text-main);
        }
        .logout-btn {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            border: 1px solid #EF4444;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: background 0.3s;
        }
        .logout-btn:hover { background: #EF4444; color: white; }
        
        .container {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
        }
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
            font-size: 0.95rem;
        }
        th {
            color: var(--text-muted);
            font-weight: 600;
            background: rgba(11, 16, 32, 0.4);
        }
        td { color: var(--text-main); }
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .status-applied { background: rgba(59, 130, 246, 0.2); color: #60A5FA; border: 1px solid #3B82F6; }
        .status-shortlisted { background: rgba(34, 197, 94, 0.2); color: #4ADE80; border: 1px solid #22C55E; }
        .status-rejected { background: rgba(239, 68, 68, 0.2); color: #F87171; border: 1px solid #EF4444; }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="color: var(--text-main);">INTERNOVA <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">/ Student Portal</span></h3>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="internships.php">Internships</a>
            <a href="application.php" class="active">Applications</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2 style="margin-bottom: 0.5rem; font-size: 1.8rem;">My Applications</h2>
        <p style="color: var(--text-muted);">Track the current status of all the internships you have applied for.</p>

        <?php if (count($applications) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Internship Role</th>
                        <th>Company</th>
                        <th>Location</th>
                        <th>Stipend</th>
                        <th>Applied On</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $app): ?>
                        <tr>
                            <td style="font-weight: 650;"><?= htmlspecialchars($app['title']) ?></td>
                            <td><?= htmlspecialchars($app['company_name']) ?></td>
                            <td style="color: var(--text-muted);"><?= htmlspecialchars($app['location']) ?></td>
                            <td style="color: #38BDF8;"><?= htmlspecialchars($app['stipend']) ?></td>
                            <td style="color: var(--text-muted);"><?= htmlspecialchars($app['created_at']) ?></td>
                            <td>
                                <?php 
                                    $status = $app['status'] ?? 'Applied';
                                    $class = 'status-applied';
                                    if (strtolower($status) === 'shortlisted' || strtolower($status) === 'interview') $class = 'status-shortlisted';
                                    if (strtolower($status) === 'rejected') $class = 'status-rejected';
                                ?>
                                <span class="status-badge <?= $class ?>"><?= htmlspecialchars($status) ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="color: var(--text-muted); margin-top: 2rem; text-align: center;">You haven't applied to any internships yet. Check out the <a href="internships.php" style="color: var(--primary-accent);">Internships page</a> to start applying!</p>
        <?php endif; ?>
    </div>
</body>
</html>