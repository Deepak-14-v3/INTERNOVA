<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

try {
    require_once '../config/database.php';

    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
        header("Location: ../login.php");
        exit();
    }

    if (!isset($pdo) && isset($conn)) {
        $pdo = $conn;
    }
    if (!isset($pdo)) {
        throw new Exception("Database connection variable not defined.");
    }

    // Automatically create student_profiles table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS student_profiles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        phone VARCHAR(50),
        degree VARCHAR(255),
        skills TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    $student_id = $_SESSION['user_id'];
    $message = '';

    // Handle profile update
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $phone = $_POST['phone'] ?? '';
        $degree = $_POST['degree'] ?? '';
        $skills = $_POST['skills'] ?? '';
        
        // Check if profile exists
        $stmt = $pdo->prepare("SELECT id FROM student_profiles WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $exists = $stmt->fetch();

        if ($exists) {
            $stmt = $pdo->prepare("UPDATE student_profiles SET phone = ?, degree = ?, skills = ? WHERE student_id = ?");
            $stmt->execute([$phone, $degree, $skills, $student_id]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO student_profiles (student_id, phone, degree, skills) VALUES (?, ?, ?, ?)");
            $stmt->execute([$student_id, $phone, $degree, $skills]);
        }
        $message = "Profile updated successfully!";
    }

    // Fetch existing profile
    $stmt = $pdo->prepare("SELECT * FROM student_profiles WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $profile = $stmt->fetch();

} catch (Exception $e) {
    echo "<div style='background: #1e1e1e; color: #ff6b6b; padding: 2rem; font-family: monospace; border: 1px solid #ff4757; border-radius: 8px; margin: 2rem;'>";
    echo "<h2 style='margin-bottom: 1rem;'>⚠️ PHP Runtime Error / Exception:</h2>";
    echo "<p style='font-size: 1.1rem;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Profile - INTERNOVA</title>
    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            padding: 2rem;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(37, 99, 235, 0.15) 0%, transparent 40%);
            background-attachment: fixed;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
        }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover, .nav-links a.active { color: var(--text-main); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            border: 1px solid #EF4444;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .logout-btn:hover { background: #EF4444; color: white; }
        .container {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
            max-width: 800px;
            margin: 0 auto;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-main);
            font-size: 1rem;
        }
        .form-control:focus { outline: none; border-color: var(--primary-accent); }
        textarea.form-control { resize: vertical; min-height: 100px; }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-accent), var(--secondary-accent));
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.3s;
        }
        .btn-primary:hover { opacity: 0.9; }
        .alert {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid #10B981;
            color: #34D399;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="color: var(--text-main);">INTERNOVA <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">/ Student Portal</span></h3>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php" class="active">Profile</a>
            <a href="internships.php">Internships</a>
            <a href="application.php">Applications</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2 style="font-size: 1.8rem; margin-bottom: 0.5rem;">Student Profile & Skills</h2>
        <p style="color: var(--text-muted); margin-bottom: 2rem;">Add your academic background and update your portfolio details.</p>

        <?php if (!empty($message)): ?>
            <div class="alert"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" name="phone" class="form-control" placeholder="+1 (555) 019-2834" value="<?= htmlspecialchars($profile['phone'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Degree / Major</label>
                <input type="text" name="degree" class="form-control" placeholder="B.Tech Computer Science" value="<?= htmlspecialchars($profile['degree'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Skills (Comma-separated)</label>
                <textarea name="skills" class="form-control" placeholder="PHP, MySQL, JavaScript, React, Git"><?= htmlspecialchars($profile['skills'] ?? '') ?></textarea>
            </div>

            <button type="submit" class="btn-primary">Save Profile Page</button>
        </form>
    </div>
</body>
</html>