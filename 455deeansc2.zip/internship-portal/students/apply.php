<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

try {
    require_once '../config/database.php';

    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
        header("Location: ../login.php");
        exit();
    }

    if (!isset($pdo) && isset($conn)) {
        $pdo = $conn;
    }
    if (!isset($pdo)) {
        throw new Exception("Database connection variable not defined.");
    }

    // Ensure applications table exists with correct schema
    $pdo->exec("CREATE TABLE IF NOT EXISTS applications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        internship_id INT NOT NULL,
        student_id INT NOT NULL,
        status VARCHAR(50) DEFAULT 'Pending',
        cover_letter TEXT,
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Ensure status column is large enough and cover_letter exists if table already existed
    try {
        $pdo->exec("ALTER TABLE applications MODIFY COLUMN status VARCHAR(50) DEFAULT 'Pending'");
        $pdo->exec("ALTER TABLE applications ADD COLUMN cover_letter TEXT");
    } catch (PDOException $ex) {
        // Ignore if columns already modified/exist
    }

    $student_id = $_SESSION['user_id'];
    $internship_id = $_GET['id'] ?? null;

    if (!$internship_id) {
        header("Location: internships.php");
        exit();
    }

    // Fetch internship details
    $stmt = $pdo->prepare("SELECT i.*, u.name as company_name FROM internships i JOIN users u ON i.company_id = u.id WHERE i.id = ?");
    $stmt->execute([$internship_id]);
    $internship = $stmt->fetch();

    if (!$internship) {
        throw new Exception("Internship not found.");
    }

    $message = '';
    $error = '';

    // Handle application submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $cover_letter = $_POST['cover_letter'] ?? '';

        // Check if already applied
        $check = $pdo->prepare("SELECT id FROM applications WHERE internship_id = ? AND student_id = ?");
        $check->execute([$internship_id, $student_id]);
        
        if ($check->fetch()) {
            $error = "You have already applied for this internship.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO applications (internship_id, student_id, status, cover_letter) VALUES (?, ?, 'Pending', ?)");
            $stmt->execute([$internship_id, $student_id, $cover_letter]);
            $message = "Application submitted successfully!";
        }
    }

} catch (Exception $e) {
    echo "<div style='background: #1e1e1e; color: #ff6b6b; padding: 2rem; font-family: monospace; border: 1px solid #ff4757; border-radius: 8px; margin: 2rem;'>";
    echo "<h2 style='margin-bottom: 1rem;'>⚠️ PHP Runtime Error / Exception:</h2>";
    echo "<p style='font-size: 1.1rem;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Apply for <?= htmlspecialchars($internship['title']) ?> - INTERNOVA</title>
    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            padding: 2rem;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(37, 99, 235, 0.15) 0%, transparent 40%);
            background-attachment: fixed;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
        }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover { color: var(--text-main); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            border: 1px solid #EF4444;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .logout-btn:hover { background: #EF4444; color: white; }
        .container {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2.5rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
            max-width: 700px;
            margin: 0 auto;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-main);
            font-size: 1rem;
        }
        .form-control:focus { outline: none; border-color: var(--primary-accent); }
        textarea.form-control { resize: vertical; min-height: 120px; }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-accent), var(--secondary-accent));
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.3s;
            width: 100%;
        }
        .btn-primary:hover { opacity: 0.9; }
        .alert {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid #10B981;
            color: #34D399;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
        .error-alert {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid #EF4444;
            color: #F87171;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="color: var(--text-main);">INTERNOVA <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">/ Student Portal</span></h3>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="internships.php">Back to Internships</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2 style="font-size: 1.8rem; margin-bottom: 0.3rem;">Apply: <?= htmlspecialchars($internship['title']) ?></h2>
        <p style="color: #38BDF8; font-weight: 500; margin-bottom: 1.5rem;"><?= htmlspecialchars($internship['company_name']) ?> &bull; 📍 <?= htmlspecialchars($internship['location']) ?></p>

        <div style="background: rgba(11, 16, 32, 0.5); border: 1px solid var(--border-color); padding: 1.2rem; border-radius: 10px; margin-bottom: 1.5rem;">
            <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.5;"><?= nl2br(htmlspecialchars($internship['description'])) ?></p>
            <div style="margin-top: 0.8rem; font-size: 0.85rem; color: var(--text-muted);">
                💰 Stipend: <strong style="color: var(--text-main);"><?= htmlspecialchars($internship['stipend']) ?></strong> &nbsp;|&nbsp; 
                🛠️ Skills: <strong style="color: var(--text-main);"><?= htmlspecialchars($internship['skills_required']) ?></strong>
            </div>
        </div>

        <?php if (!empty($message)): ?>
            <div class="alert"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error-alert"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Cover Letter / Statement of Purpose</label>
                <textarea name="cover_letter" class="form-control" placeholder="Explain why you are a great fit for this role..."></textarea>
            </div>

            <button type="submit" class="btn-primary">Submit Application</button>
        </form>
    </div>
</body>
</html>