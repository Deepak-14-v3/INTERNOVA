<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

try {
    require_once '../config/database.php';

    // Security check
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
        header("Location: ../login.php");
        exit();
    }

    // Ensure PDO exists
    if (!isset($pdo) && isset($conn)) {
        $pdo = $conn;
    }
    if (!isset($pdo)) {
        throw new Exception("Database connection variable (\$pdo or \$conn) is not defined in config/database.php");
    }

    $search = $_GET['search'] ?? '';

    // Fetch internships matching search (removed status check)
    $query = "SELECT internships.*, users.name as company_name FROM internships JOIN users ON internships.company_id = users.id WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $query .= " AND (internships.title LIKE ? OR internships.skills_required LIKE ? OR users.name LIKE ?)";
        $searchTerm = "%$search%";
        $params = [$searchTerm, $searchTerm, $searchTerm];
    }

    $query .= " ORDER BY internships.created_at DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $internships = $stmt->fetchAll();

} catch (Exception $e) {
    echo "<div style='background: #1e1e1e; color: #ff6b6b; padding: 2rem; font-family: monospace; border: 1px solid #ff4757; border-radius: 8px; margin: 2rem;'>";
    echo "<h2 style='margin-bottom: 1rem;'>⚠️ PHP Runtime Error / Exception:</h2>";
    echo "<p style='font-size: 1.1rem;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Explore Internships - INTERNOVA</title>
    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            padding: 2rem;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(37, 99, 235, 0.15) 0%, transparent 40%);
            background-attachment: fixed;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
        }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover, .nav-links a.active { color: var(--text-main); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            border: 1px solid #EF4444;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .logout-btn:hover { background: #EF4444; color: white; }
        .container {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
        }
        .search-bar {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            margin-bottom: 2rem;
        }
        .search-bar input {
            flex: 1;
            padding: 0.75rem 1rem;
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-main);
            font-size: 1rem;
        }
        .search-bar input:focus { outline: none; border-color: var(--primary-accent); }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-accent), var(--secondary-accent));
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.3s;
        }
        .btn-primary:hover { opacity: 0.9; }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        .card {
            background: rgba(11, 16, 32, 0.5);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .card h3 { font-size: 1.25rem; margin-bottom: 0.5rem; color: var(--text-main); }
        .card p { color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1rem; }
        .details { font-size: 0.85rem; color: #38BDF8; margin-bottom: 1rem; }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="color: var(--text-main);">INTERNOVA <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">/ Student Portal</span></h3>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="internships.php" class="active">Internships</a>
            <a href="application.php">Applications</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2 style="font-size: 1.8rem; margin-bottom: 0.5rem;">Explore Internships</h2>
        <p style="color: var(--text-muted);">Find and apply to the latest internship opportunities.</p>

        <form method="GET" class="search-bar">
            <input type="text" name="search" placeholder="Search by skills, role, or company..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn-primary">Search</button>
        </form>

        <?php if (!empty($internships) && count($internships) > 0): ?>
            <div class="grid">
                <?php foreach ($internships as $item): ?>
                    <div class="card">
                        <div>
                            <h3><?= htmlspecialchars($item['title']) ?></h3>
                            <p style="color: var(--primary-accent); font-weight: 500; margin-bottom: 0.5rem;"><?= htmlspecialchars($item['company_name']) ?></p>
                            <p><?= nl2br(htmlspecialchars($item['description'])) ?></p>
                        </div>
                        <div>
                            <div class="details">
                                📍 <?= htmlspecialchars($item['location']) ?> &nbsp;|&nbsp; 💰 <?= htmlspecialchars($item['stipend']) ?>
                            </div>
                            <a href="apply.php?id=<?= $item['id'] ?>" class="btn-primary" style="display: block; text-align: center; text-decoration: none;">Apply Now</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="color: var(--text-muted); text-align: center; margin-top: 3rem;">No internship positions match your search criteria.</p>
        <?php endif; ?>
    </div>
</body>
</html>