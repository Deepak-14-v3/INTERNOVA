<?php
session_start();
require_once '../config/database.php';

// Security check: ensure user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

$student_name = $_SESSION['name'];
$student_id = $_SESSION['user_id'];

// Fetch application counts
$stmt = $pdo->prepare("SELECT COUNT(*) FROM applications WHERE student_id = ?");
$stmt->execute([$student_id]);
$total_apps = $stmt->fetchColumn();

$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM applications WHERE student_id = ? AND status IN ('Shortlisted', 'Interview')");
$stmt2->execute([$student_id]);
$shortlisted_apps = $stmt2->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard - INTERNOVA</title>
    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
            --success: #22C55E;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            padding: 2rem;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(37, 99, 235, 0.15) 0%, transparent 40%);
            background-attachment: fixed;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
        }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover, .nav-links a.active {
            color: var(--text-main);
        }
        .logout-btn {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            border: 1px solid #EF4444;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: background 0.3s;
        }
        .logout-btn:hover { background: #EF4444; color: white; }
        
        .welcome-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2.5rem;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            backdrop-filter: blur(16px);
        }
        .stat-card h3 { font-size: 0.9rem; color: var(--text-muted); margin-bottom: 0.5rem; }
        .stat-card .number { font-size: 2.5rem; font-weight: 700; color: var(--text-main); }
        
        .actions-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            backdrop-filter: blur(16px);
        }
        .btn-action {
            display: inline-block;
            background: linear-gradient(135deg, var(--primary-accent), var(--secondary-accent));
            color: white;
            padding: 0.7rem 1.2rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            margin-right: 1rem;
            margin-top: 1rem;
        }
        .btn-action:hover { opacity: 0.9; }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="color: var(--text-main);">INTERNOVA <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">/ Student Portal</span></h3>
        <div class="nav-links">
            <a href="dashboard.php" class="active">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="internships.php">Internships</a>
            <a href="application.php">Applications</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="welcome-card">
        <h2 style="font-size: 2rem; margin-bottom: 0.5rem;">Welcome back, <?= htmlspecialchars($student_name) ?>! 👋</h2>
        <p style="color: var(--text-muted);">Track your placement status and explore active career openings.</p>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <h3>Total Applications</h3>
            <div class="number"><?= $total_apps ?></div>
        </div>
        <div class="stat-card">
            <h3>Shortlisted / Interviews</h3>
            <div class="number" style="color: #38BDF8;"><?= $shortlisted_apps ?></div>
        </div>
    </div>

    <div class="actions-card">
        <h3 style="margin-bottom: 0.5rem;">Quick Career Actions</h3>
        <p style="color: var(--text-muted); font-size: 0.95rem;">Keep your profile and skill tags up to date for better matching.</p>
        <div>
            <a href="internships.php" class="btn-action">Browse Openings</a>
            <a href="profile.php" class="btn-action" style="background: rgba(255,255,255,0.05); border: 1px solid var(--border-color);">Manage Profile</a>
        </div>
    </div>
</body>
</html>