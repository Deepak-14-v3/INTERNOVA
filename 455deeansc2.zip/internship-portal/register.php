<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'config/database.php';

$error = '';
$selected_role = $_GET['role'] ?? 'student';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $checkStmt->execute([$email]);

        if ($checkStmt->rowCount() > 0) {
            $error = "Registration failed: The email address '$email' is already registered. Please log in instead.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            try {
                $stmt = $pdo->prepare(
                    "INSERT INTO users (name, email, password, role)
                     VALUES (?, ?, ?, ?)"
                );

                $stmt->execute([
                    $name,
                    $email,
                    $hashed_password,
                    $role
                ]);

                header("Location: login.php?registered=success");
                exit();
            } catch (PDOException $e) {
                $error = "Registration failed: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Account - INTERNOVA</title>

    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
            --success: #22C55E;
            --error: #EF4444;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        body {
            min-height: 100vh;
            padding: 35px 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow-x: hidden;
            color: var(--text-main);
            background-color: var(--bg-main);
            background-image:
                radial-gradient(
                    circle at 10% 20%,
                    rgba(124, 58, 237, 0.15) 0%,
                    transparent 40%
                ),
                radial-gradient(
                    circle at 90% 80%,
                    rgba(37, 99, 235, 0.15) 0%,
                    transparent 40%
                );
            background-attachment: fixed;
        }

        .ambient {
            position: fixed;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            filter: blur(100px);
            opacity: 0.12;
            pointer-events: none;
            z-index: -1;
            animation: ambientMove 12s ease-in-out infinite alternate;
        }

        .ambient-one {
            top: 5%;
            left: -150px;
            background: var(--primary-accent);
        }

        .ambient-two {
            right: -150px;
            bottom: 0;
            background: var(--secondary-accent);
            animation-delay: -5s;
        }

        .register-wrapper {
            width: 100%;
            max-width: 480px;
            animation: cardEntrance 0.7s ease both;
        }

        /* Registration card */

        .glass-card {
            position: relative;
            overflow: hidden;
            width: 100%;
            padding: 36px;
            border: 1px solid var(--border-color);
            border-radius: 20px;
            background: var(--card-bg);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            box-shadow: 0 20px 65px rgba(0, 0, 0, 0.28);
            transition:
                border-color 0.35s ease,
                box-shadow 0.35s ease;
        }

        .glass-card:hover {
            border-color: rgba(124, 58, 237, 0.5);
            box-shadow: 0 24px 75px rgba(0, 0, 0, 0.32);
        }

        /* INTERNOVA brand inside the card */

        .card-brand {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            width: fit-content;
            margin: 0 auto 30px;
            text-decoration: none;
        }

        .brand-icon {
            width: 58px;
            height: 58px;
            display: grid;
            place-items: center;
            border: 1px solid rgba(255, 255, 255, 0.14);
            border-radius: 17px;
            background: linear-gradient(
                135deg,
                var(--primary-accent),
                var(--secondary-accent)
            );
            color: white;
            font-size: 29px;
            font-weight: 850;
            box-shadow: 0 8px 28px rgba(124, 58, 237, 0.3);
            transition:
                transform 0.3s ease,
                box-shadow 0.3s ease;
        }

        .card-brand:hover .brand-icon {
            transform: translateY(-3px) rotate(-5deg);
            box-shadow: 0 12px 35px rgba(124, 58, 237, 0.45);
        }

        .brand-name {
            color: var(--text-main);
            font-size: 1.65rem;
            font-weight: 850;
            letter-spacing: 2px;
        }

        .brand-name span {
            background: linear-gradient(
                135deg,
                #A78BFA,
                #60A5FA
            );
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .brand-caption {
            margin-top: -5px;
            color: var(--text-muted);
            font-size: 0.7rem;
            font-weight: 600;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        /* Heading */

        .card-heading {
            margin-bottom: 28px;
            text-align: center;
        }

        .card-heading h1 {
            margin-bottom: 10px;
            color: var(--text-main);
            font-size: clamp(1.8rem, 5vw, 2.15rem);
            font-weight: 800;
            letter-spacing: -0.8px;
        }

        .card-heading p {
            max-width: 330px;
            margin: 0 auto;
            color: var(--text-muted);
            font-size: 0.94rem;
            line-height: 1.7;
        }

        /* Form fields */

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 9px;
            color: var(--text-main);
            font-size: 0.88rem;
            font-weight: 600;
        }

        .input-group {
            position: relative;
        }

        .input-group input,
        .input-group select {
            display: block;
            width: 100%;
            min-height: 49px;
            padding: 13px 15px;
            border: 1px solid var(--border-color);
            border-radius: 10px;
            outline: none;
            background: rgba(11, 16, 32, 0.85);
            color: var(--text-main);
            font-size: 0.94rem;
            transition:
                border-color 0.25s ease,
                box-shadow 0.25s ease,
                background 0.25s ease;
        }

        .input-group input::placeholder {
            color: #718096;
            opacity: 1;
        }

        .input-group input:hover,
        .input-group select:hover {
            border-color: #46516B;
        }

        .input-group input:focus,
        .input-group select:focus {
            border-color: var(--primary-accent);
            background: rgba(11, 16, 32, 0.98);
            box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.17);
        }

        .input-group select {
            padding-right: 35px;
            cursor: pointer;
        }

        .input-group select option {
            background: var(--bg-secondary);
            color: var(--text-main);
        }

        .password-input {
            padding-right: 50px !important;
        }

        /* Password visibility controls */

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            transform: translateY(-50%);
            border: none;
            border-radius: 7px;
            background: transparent;
            color: var(--text-muted);
            cursor: pointer;
            transition:
                color 0.25s ease,
                background 0.25s ease;
        }

        .toggle-password:hover {
            color: var(--text-main);
            background: rgba(124, 58, 237, 0.15);
        }

        .toggle-password:focus-visible {
            outline: 2px solid var(--primary-accent);
            outline-offset: 2px;
        }

        .toggle-password svg {
            width: 20px;
            height: 20px;
        }

        .password-hint {
            margin-top: 8px;
            color: var(--text-muted);
            font-size: 0.77rem;
        }

        /* Error message */

        .badge-error {
            margin-bottom: 22px;
            padding: 13px 14px;
            border: 1px solid rgba(239, 68, 68, 0.45);
            border-radius: 10px;
            background: rgba(239, 68, 68, 0.1);
            color: #FCA5A5;
            font-size: 0.86rem;
            line-height: 1.6;
            overflow-wrap: anywhere;
            animation: errorEntrance 0.35s ease both;
        }

        /* Registration button */

        .btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            min-height: 51px;
            margin-top: 7px;
            padding: 14px 18px;
            border: 1px solid transparent;
            border-radius: 10px;
            background: linear-gradient(
                135deg,
                var(--primary-accent),
                var(--secondary-accent)
            );
            color: white;
            font-size: 0.96rem;
            font-weight: 700;
            cursor: pointer;
            transition:
                transform 0.25s ease,
                box-shadow 0.25s ease,
                filter 0.25s ease;
        }

        .btn:hover {
            transform: translateY(-3px);
            filter: brightness(1.08);
            box-shadow: 0 10px 28px rgba(124, 58, 237, 0.28);
        }

        .btn:active {
            transform: translateY(0) scale(0.99);
        }

        .btn-arrow {
            display: inline-block;
            transition: transform 0.25s ease;
        }

        .btn:hover .btn-arrow {
            transform: translateX(4px);
        }

        /* Login and homepage links */

        .login-link {
            margin-top: 25px;
            padding-top: 22px;
            border-top: 1px solid rgba(38, 50, 71, 0.8);
            color: var(--text-muted);
            font-size: 0.9rem;
            text-align: center;
        }

        .login-link a {
            margin-left: 4px;
            color: #A78BFA;
            font-weight: 700;
            text-decoration: none;
            transition: color 0.25s ease;
        }

        .login-link a:hover {
            color: #C4B5FD;
            text-decoration: underline;
            text-underline-offset: 4px;
        }

        .back-home {
            display: block;
            width: fit-content;
            margin: 23px auto 0;
            color: var(--text-muted);
            font-size: 0.86rem;
            text-decoration: none;
            transition:
                color 0.25s ease,
                transform 0.25s ease;
        }

        .back-home:hover {
            color: var(--text-main);
            transform: translateX(-3px);
        }

        a:focus-visible {
            outline: 2px solid var(--success);
            outline-offset: 4px;
        }

        /* Animations */

        @keyframes cardEntrance {
            from {
                opacity: 0;
                transform: translateY(22px) scale(0.985);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        @keyframes errorEntrance {
            from {
                opacity: 0;
                transform: translateY(-5px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes ambientMove {
            from {
                transform: translate(0, 0) scale(1);
            }
            to {
                transform: translate(35px, -25px) scale(1.12);
            }
        }

        /* Responsive design */

        @media (max-width: 480px) {
            body {
                padding: 24px 13px;
            }

            .glass-card {
                padding: 25px 20px;
                border-radius: 16px;
            }

            .card-brand {
                margin-bottom: 25px;
            }

            .brand-icon {
                width: 52px;
                height: 52px;
                border-radius: 15px;
            }

            .brand-name {
                font-size: 1.45rem;
            }

            .brand-caption {
                font-size: 0.65rem;
            }

            .card-heading {
                margin-bottom: 24px;
            }

            .form-group {
                margin-bottom: 18px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>

<body>

    <div class="ambient ambient-one"></div>
    <div class="ambient ambient-two"></div>

    <main class="register-wrapper">

        <section class="glass-card">

            <!-- INTERNOVA brand inside the registration card -->
            <a href="index.php" class="card-brand"
               aria-label="INTERNOVA Home">

                <span class="brand-icon">I</span>

                <span class="brand-name">
                    INTER<span>NOVA</span>
                </span>

                <span class="brand-caption">
                    Launch Your Career Orbit
                </span>

            </a>

            <div class="card-heading">
                <h1>Create Account</h1>
                <p>
                    Join INTERNOVA and take the next step in your
                    professional journey.
                </p>
            </div>

            <?php if ($error): ?>
                <div class="badge-error" role="alert">
                    <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST" id="registerForm">

                <div class="form-group">
                    <label for="name">
                        Full Name / Organization Name
                    </label>

                    <div class="input-group">
                        <input
                            type="text"
                            id="name"
                            name="name"
                            required
                            autocomplete="name"
                            placeholder="Enter your full name"
                            value="<?= htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email ID</label>

                    <div class="input-group">
                        <input
                            type="email"
                            id="email"
                            name="email"
                            required
                            autocomplete="email"
                            placeholder="Enter your Email ID"
                            value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>

                    <div class="input-group">
                        <input
                            type="password"
                            class="password-input"
                            name="password"
                            id="password"
                            required
                            autocomplete="new-password"
                            placeholder="Create a password"
                        >

                        <button
                            type="button"
                            class="toggle-password"
                            aria-label="Show password"
                            aria-pressed="false"
                            onclick="togglePassword('password', 'eye-icon-1', this)"
                        >
                            <svg id="eye-icon-1"
                                 fill="none"
                                 stroke="currentColor"
                                 stroke-width="2"
                                 viewBox="0 0 24 24"
                                 aria-hidden="true">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>

                    <p class="password-hint">
                        Choose a password and keep it secure.
                    </p>
                </div>

                <div class="form-group">
                    <label for="confirm_password">
                        Confirm Password
                    </label>

                    <div class="input-group">
                        <input
                            type="password"
                            class="password-input"
                            name="confirm_password"
                            id="confirm_password"
                            required
                            autocomplete="new-password"
                            placeholder="Re-enter your password"
                        >

                        <button
                            type="button"
                            class="toggle-password"
                            aria-label="Show confirm password"
                            aria-pressed="false"
                            onclick="togglePassword('confirm_password', 'eye-icon-2', this)"
                        >
                            <svg id="eye-icon-2"
                                 fill="none"
                                 stroke="currentColor"
                                 stroke-width="2"
                                 viewBox="0 0 24 24"
                                 aria-hidden="true">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="role">Register As</label>

                    <div class="input-group">
                        <select name="role" id="role">
                            <option value="student"
                                <?= $selected_role === 'student' ? 'selected' : '' ?>>
                                Student
                            </option>

                            <option value="company"
                                <?= $selected_role === 'company' ? 'selected' : '' ?>>
                                Company / Admin
                            </option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn">
                    Complete Registration
                    <span class="btn-arrow">→</span>
                </button>

            </form>

            <p class="login-link">
                Already registered?
                <a href="login.php">Login to your account</a>
            </p>

        </section>

        <a href="index.php" class="back-home">
            ← Back to Homepage
        </a>

    </main>

    <script>
        function togglePassword(fieldId, iconId, button) {
            const field = document.getElementById(fieldId);
            const icon = document.getElementById(iconId);

            if (field.type === 'password') {
                field.type = 'text';

                button.setAttribute('aria-label', 'Hide password');
                button.setAttribute('aria-pressed', 'true');

                icon.innerHTML =
                    '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line>';
            } else {
                field.type = 'password';

                button.setAttribute('aria-label', 'Show password');
                button.setAttribute('aria-pressed', 'false');

                icon.innerHTML =
                    '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>';
            }
        }

        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const pass = document.getElementById('password').value;
            const confirmPass = document.getElementById('confirm_password').value;

            if (pass !== confirmPass) {
                e.preventDefault();
                alert('Passwords do not match. Please verify.');
            }
        });
    </script>

</body>
</html>