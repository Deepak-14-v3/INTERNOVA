// js/validation.js - Form validation & interactivity
document.addEventListener('DOMContentLoaded', () => {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const pass = form.querySelector('input[name="password"]');
            const confirmPass = form.querySelector('input[name="confirm_password"]');
            if (pass && confirmPass && pass.value !== confirmPass.value) {
                e.preventDefault();
                alert('Passwords do not match!');
            }
        });
    });
});