<?php
// company/internships.php - Company view postings manager
header("Location: dashboard.php");
exit();
?>