<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

try {
    require_once '../config/database.php';

    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
        header("Location: ../login.php");
        exit();
    }

    if (!isset($pdo) && isset($conn)) {
        $pdo = $conn;
    }
    if (!isset($pdo)) {
        throw new Exception("Database connection variable not defined.");
    }

    // Ensure applications table exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS applications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        internship_id INT NOT NULL,
        student_id INT NOT NULL,
        status VARCHAR(50) DEFAULT 'Pending',
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Safely add applied_at column if it was missing from an older table version
    try {
        $pdo->exec("ALTER TABLE applications ADD COLUMN applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
    } catch (PDOException $ex) {
        // Column likely already exists, ignore exception
    }

    $company_id = $_SESSION['user_id'];
    $message = '';

    // Handle status updates if posted
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id'], $_POST['status'])) {
        $app_id = $_POST['application_id'];
        $new_status = $_POST['status'];
        
        $update_stmt = $pdo->prepare("
            UPDATE applications a 
            JOIN internships i ON a.internship_id = i.id 
            SET a.status = ? 
            WHERE a.id = ? AND i.company_id = ?
        ");
        $update_stmt->execute([$new_status, $app_id, $company_id]);
        $message = "Application status updated successfully!";
    }

    // Fetch applicants for this company's internships
    $stmt = $pdo->prepare("
        SELECT a.id as application_id, a.status, a.applied_at, 
               i.title as internship_title, 
               u.name as student_name, u.email as student_email,
               p.phone, p.degree, p.skills
        FROM applications a
        JOIN internships i ON a.internship_id = i.id
        JOIN users u ON a.student_id = u.id
        LEFT JOIN student_profiles p ON u.id = p.student_id
        WHERE i.company_id = ?
        ORDER BY a.applied_at DESC
    ");
    $stmt->execute([$company_id]);
    $applicants = $stmt->fetchAll();

} catch (Exception $e) {
    echo "<div style='background: #1e1e1e; color: #ff6b6b; padding: 2rem; font-family: monospace; border: 1px solid #ff4757; border-radius: 8px; margin: 2rem;'>";
    echo "<h2 style='margin-bottom: 1rem;'>⚠️ PHP Runtime Error / Exception:</h2>";
    echo "<p style='font-size: 1.1rem;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Applicants - INTERNOVA</title>
    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            padding: 2rem;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(37, 99, 235, 0.15) 0%, transparent 40%);
            background-attachment: fixed;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
        }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover, .nav-links a.active { color: var(--text-main); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            border: 1px solid #EF4444;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .logout-btn:hover { background: #EF4444; color: white; }
        .container {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
            max-width: 1000px;
            margin: 0 auto;
        }
        .alert {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid #10B981;
            color: #34D399;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }
        .applicant-card {
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.2rem;
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
            align-items: center;
        }
        @media(max-width: 768px) {
            .applicant-card { grid-template-columns: 1fr; }
        }
        .applicant-info h4 { font-size: 1.2rem; color: var(--text-main); margin-bottom: 0.2rem; }
        .applicant-info p { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 0.4rem; }
        .badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        .badge-Pending { background: rgba(234, 179, 8, 0.2); color: #FACC15; border: 1px solid #EAB308; }
        .badge-Accepted { background: rgba(16, 185, 129, 0.2); color: #34D399; border: 1px solid #10B981; }
        .badge-Rejected { background: rgba(239, 68, 68, 0.2); color: #EF4444; border: 1px solid #EF4444; }
        
        .action-form {
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
            align-items: flex-end;
        }
        @media(max-width: 768px) {
            .action-form { align-items: flex-start; }
        }
        .form-control {
            padding: 0.5rem;
            background: rgba(11, 16, 32, 0.8);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-main);
            font-size: 0.9rem;
            width: 100%;
        }
        .btn-sm {
            background: linear-gradient(135deg, var(--primary-accent), var(--secondary-accent));
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            font-size: 0.85rem;
            transition: opacity 0.3s;
        }
        .btn-sm:hover { opacity: 0.9; }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="color: var(--text-main);">INTERNOVA <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">/ Employer Portal</span></h3>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="applicants.php" class="active">Applicants</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2 style="font-size: 1.8rem; margin-bottom: 0.5rem;">Applicant Review Management</h2>
        <p style="color: var(--text-muted); margin-bottom: 2rem;">Review and manage students who have applied to your internship openings.</p>

        <?php if (!empty($message)): ?>
            <div class="alert"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <?php if (!empty($applicants) && count($applicants) > 0): ?>
            <div style="max-height: 600px; overflow-y: auto; padding-right: 0.5rem;">
                <?php foreach ($applicants as $app): ?>
                    <div class="applicant-card">
                        <div class="applicant-info">
                            <h4><?= htmlspecialchars($app['student_name']) ?> <span style="font-weight: normal; font-size: 0.9rem; color: var(--text-muted);">(&#9993; <?= htmlspecialchars($app['student_email']) ?>)</span></h4>
                            <p style="color: #38BDF8; font-weight: 500;">Applied for: <?= htmlspecialchars($app['internship_title']) ?></p>
                            <p><strong>Degree:</strong> <?= htmlspecialchars($app['degree'] ?? 'Not specified') ?> &nbsp;|&nbsp; <strong>Phone:</strong> <?= htmlspecialchars($app['phone'] ?? 'Not specified') ?></p>
                            <p><strong>Skills:</strong> <?= htmlspecialchars($app['skills'] ?? 'Not specified') ?></p>
                            <p style="margin-top: 0.5rem;"><span class="badge badge-<?= htmlspecialchars($app['status']) ?>">Status: <?= htmlspecialchars($app['status']) ?></span> &nbsp;<span style="font-size: 0.8rem; color: var(--text-muted);">Applied on: <?= htmlspecialchars($app['applied_at']) ?></span></p>
                        </div>
                        <div class="action-form">
                            <form method="POST" style="width: 100%;">
                                <input type="hidden" name="application_id" value="<?= $app['application_id'] ?>">
                                <div style="margin-bottom: 0.5rem;">
                                    <select name="status" class="form-control">
                                        <option value="Pending" <?= $app['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="Accepted" <?= $app['status'] === 'Accepted' ? 'selected' : '' ?>>Accepted</option>
                                        <option value="Rejected" <?= $app['status'] === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn-sm" style="width: 100%;">Update Status</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="color: var(--text-muted); text-align: center; margin-top: 3rem;">No candidates have applied to your postings yet.</p>
        <?php endif; ?>
    </div>
</body>
</html>