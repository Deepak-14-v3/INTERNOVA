<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

try {
    require_once '../config/database.php';

    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
        header("Location: ../login.php");
        exit();
    }

    if (!isset($pdo) && isset($conn)) {
        $pdo = $conn;
    }
    if (!isset($pdo)) {
        throw new Exception("Database connection variable not defined.");
    }

    // Ensure internships table exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS internships (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        skills_required VARCHAR(255),
        stipend VARCHAR(100),
        location VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    $company_id = $_SESSION['user_id'];
    $message = '';

    // Handle new internship posting
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $title = $_POST['title'] ?? '';
        $skills = $_POST['skills_required'] ?? '';
        $stipend = $_POST['stipend'] ?? '';
        $location = $_POST['location'] ?? '';
        $description = $_POST['description'] ?? '';

        if (!empty($title) && !empty($description)) {
            $stmt = $pdo->prepare("INSERT INTO internships (company_id, title, description, skills_required, stipend, location) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$company_id, $title, $description, $skills, $stipend, $location]);
            $message = "Internship listing published successfully!";
        } else {
            $message = "Title and Description are required.";
        }
    }

    // Fetch posted listings
    $stmt = $pdo->prepare("SELECT * FROM internships WHERE company_id = ? ORDER BY created_at DESC");
    $stmt->execute([$company_id]);
    $listings = $stmt->fetchAll();

} catch (Exception $e) {
    echo "<div style='background: #1e1e1e; color: #ff6b6b; padding: 2rem; font-family: monospace; border: 1px solid #ff4757; border-radius: 8px; margin: 2rem;'>";
    echo "<h2 style='margin-bottom: 1rem;'>⚠️ PHP Runtime Error / Exception:</h2>";
    echo "<p style='font-size: 1.1rem;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Company Dashboard - INTERNOVA</title>
    <style>
        :root {
            --bg-main: #0B1020;
            --card-bg: rgba(21, 29, 46, 0.85);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        body {
            background-color: var(--bg-main);
            color: var(--text-main);
            min-height: 100vh;
            padding: 2rem;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(37, 99, 235, 0.15) 0%, transparent 40%);
            background-attachment: fixed;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            backdrop-filter: blur(16px);
        }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover, .nav-links a.active { color: var(--text-main); }
        .logout-btn {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            border: 1px solid #EF4444;
            padding: 0.4rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }
        .logout-btn:hover { background: #EF4444; color: white; }
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }
        @media(max-width: 968px) {
            .dashboard-grid { grid-template-columns: 1fr; }
        }
        .container {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 2rem;
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.4);
        }
        .form-group {
            margin-bottom: 1.2rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.4rem;
            color: var(--text-muted);
            font-weight: 500;
            font-size: 0.9rem;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-main);
            font-size: 0.95rem;
        }
        .form-control:focus { outline: none; border-color: var(--primary-accent); }
        textarea.form-control { resize: vertical; min-height: 100px; }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-accent), var(--secondary-accent));
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: opacity 0.3s;
        }
        .btn-primary:hover { opacity: 0.9; }
        .alert {
            background: rgba(16, 185, 129, 0.2);
            border: 1px solid #10B981;
            color: #34D399;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }
        .listing-card {
            background: rgba(11, 16, 32, 0.5);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 1.2rem;
            margin-bottom: 1rem;
        }
        .listing-card h4 { font-size: 1.1rem; margin-bottom: 0.3rem; color: var(--text-main); }
        .listing-card p { color: var(--text-muted); font-size: 0.9rem; margin-bottom: 0.5rem; }
        .listing-details { font-size: 0.85rem; color: #38BDF8; }
    </style>
</head>
<body>
    <div class="navbar">
        <h3 style="color: var(--text-main);">INTERNOVA <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">/ Employer Portal</span></h3>
        <div class="nav-links">
            <a href="dashboard.php" class="active">Dashboard</a>
            <a href="applicants.php">Applicants</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="dashboard-grid">
        <!-- Post New Internship Form -->
        <div class="container">
            <h2 style="font-size: 1.6rem; margin-bottom: 0.5rem;">Post New Internship Opening</h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem;">Create a listing to find talented student interns.</p>

            <?php if (!empty($message)): ?>
                <div class="alert"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>Internship Title</label>
                    <input type="text" name="title" class="form-control" placeholder="Full Stack Developer Intern" required>
                </div>

                <div class="form-group">
                    <label>Required Skills (Comma separated)</label>
                    <input type="text" name="skills_required" class="form-control" placeholder="PHP, MySQL, React">
                </div>

                <div class="form-group">
                    <label>Stipend</label>
                    <input type="text" name="stipend" class="form-control" placeholder="$800/month">
                </div>

                <div class="form-group">
                    <label>Location / Mode</label>
                    <input type="text" name="location" class="form-control" placeholder="Remote / New York">
                </div>

                <div class="form-group">
                    <label>Job Description</label>
                    <textarea name="description" class="form-control" placeholder="Provide role overview and expectations..." required></textarea>
                </div>

                <button type="submit" class="btn-primary">Publish Listing</button>
            </form>
        </div>

        <!-- Your Posted Listings -->
        <div class="container">
            <h2 style="font-size: 1.6rem; margin-bottom: 0.5rem;">Your Posted Listings</h2>
            <p style="color: var(--text-muted); margin-bottom: 1.5rem; font-size: 0.95rem;">Manage your active internship postings.</p>

            <?php if (!empty($listings) && count($listings) > 0): ?>
                <div style="max-height: 550px; overflow-y: auto; padding-right: 0.5rem;">
                    <?php foreach ($listings as $item): ?>
                        <div class="listing-card">
                            <h4><?= htmlspecialchars($item['title']) ?></h4>
                            <p><?= nl2br(htmlspecialchars($item['description'])) ?></p>
                            <div class="listing-details">
                                📍 <?= htmlspecialchars($item['location']) ?> &nbsp;|&nbsp; 💰 <?= htmlspecialchars($item['stipend']) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="color: var(--text-muted); text-align: center; margin-top: 3rem;">No listings created yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>