<?php
// company/add_internship.php - Redirects to main employer dashboard manager
header("Location: dashboard.php");
exit();
?>