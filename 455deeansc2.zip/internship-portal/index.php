<?php
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>INTERNOVA - Launch Your Career Orbit</title>

    <link rel="stylesheet" href="/css/style.css">

    <style>
        :root {
            --bg-main: #0B1020;
            --bg-secondary: #111827;
            --card-bg: rgba(21, 29, 46, 0.75);
            --primary-accent: #7C3AED;
            --secondary-accent: #2563EB;
            --text-main: #F8FAFC;
            --text-muted: #94A3B8;
            --border-color: #263247;
            --success: #22C55E;
        }

        .home-page,
        .home-page * {
            box-sizing: border-box;
        }

        .home-page {
            min-height: 100vh;
            overflow: hidden;
            background: var(--bg-main);
            color: var(--text-main);
            font-family: 'Segoe UI', system-ui, sans-serif;
            position: relative;
            isolation: isolate;
        }

        .home-page a {
            text-decoration: none;
        }

        .home-page .ambient {
            position: absolute;
            width: 380px;
            height: 380px;
            border-radius: 50%;
            filter: blur(100px);
            opacity: 0.17;
            pointer-events: none;
            z-index: -1;
            animation: ambientFloat 12s ease-in-out infinite alternate;
        }

        .home-page .ambient-purple {
            background: var(--primary-accent);
            top: 100px;
            left: -180px;
        }

        .home-page .ambient-blue {
            background: var(--secondary-accent);
            right: -180px;
            top: 300px;
            animation-delay: -5s;
        }

        /* Navigation */

        .home-page .site-nav {
            width: min(1200px, 100%);
            margin: 0 auto;
            padding: 25px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            animation: slideDown 0.7s ease both;
        }

        .home-page .brand {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            color: var(--text-main);
        }

        .home-page .brand-icon {
            width: 43px;
            height: 43px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            background: linear-gradient(
                135deg,
                var(--primary-accent),
                var(--secondary-accent)
            );
            color: white;
            font-size: 23px;
            font-weight: 800;
            box-shadow: 0 5px 25px rgba(124, 58, 237, 0.25);
            transition: transform 0.35s ease, box-shadow 0.35s ease;
        }

        .home-page .brand:hover .brand-icon {
            transform: rotate(-8deg) scale(1.08);
            box-shadow: 0 8px 30px rgba(124, 58, 237, 0.45);
        }

        .home-page .brand-name {
            font-size: 1.55rem;
            font-weight: 850;
            letter-spacing: 1.5px;
            background: linear-gradient(
                135deg,
                #7C3AED,
                #2563EB
            );
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .home-page .nav-actions {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        /* Buttons */

        .home-page .action-btn {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 9px;
            min-height: 46px;
            padding: 12px 22px;
            border: 1px solid transparent;
            border-radius: 10px;
            color: white;
            font-size: 0.94rem;
            font-weight: 650;
            cursor: pointer;
            transition:
                transform 0.25s ease,
                box-shadow 0.25s ease,
                background 0.25s ease,
                border-color 0.25s ease;
        }

        .home-page .btn-primary {
            background: linear-gradient(
                135deg,
                var(--primary-accent),
                var(--secondary-accent)
            );
            box-shadow: 0 5px 20px rgba(124, 58, 237, 0.17);
        }

        .home-page .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(124, 58, 237, 0.36);
        }

        .home-page .btn-outline {
            background: rgba(17, 24, 39, 0.55);
            border-color: var(--border-color);
        }

        .home-page .btn-outline:hover {
            transform: translateY(-3px);
            border-color: var(--primary-accent);
            background: rgba(124, 58, 237, 0.12);
            box-shadow: 0 7px 22px rgba(0, 0, 0, 0.18);
        }

        .home-page .action-btn:active {
            transform: translateY(0) scale(0.98);
        }

        .home-page a:focus-visible {
            outline: 2px solid var(--success);
            outline-offset: 5px;
        }

        /* Hero */

        .home-page .hero {
            max-width: 1100px;
            margin: 0 auto;
            padding: 100px 25px 75px;
            text-align: center;
        }

        .home-page .hero-content {
            animation: heroReveal 0.9s ease 0.1s both;
        }

        .home-page .eyebrow {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 27px;
            padding: 10px 16px;
            border: 1px solid rgba(34, 197, 94, 0.38);
            border-radius: 50px;
            background: rgba(34, 197, 94, 0.09);
            color: var(--success);
            font-size: 0.76rem;
            font-weight: 750;
            letter-spacing: 1.4px;
            text-transform: uppercase;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .home-page .eyebrow:hover {
            background: rgba(34, 197, 94, 0.16);
            transform: translateY(-2px);
        }

        .home-page .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--success);
            box-shadow: 0 0 12px rgba(34, 197, 94, 0.65);
            animation: dotPulse 2s ease-in-out infinite;
        }

        .home-page .hero h1 {
            max-width: 950px;
            margin: 0 auto 24px;
            color: var(--text-main);
            font-size: clamp(2.5rem, 6vw, 4.65rem);
            font-weight: 850;
            line-height: 1.1;
            letter-spacing: -2.5px;
        }

        .home-page .gradient-text {
            display: inline-block;
            padding-bottom: 5px;
            background: linear-gradient(
                100deg,
                #A78BFA 5%,
                #7C3AED 40%,
                #60A5FA 90%
            );
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: gradientFlow 6s ease-in-out infinite alternate;
        }

        .home-page .hero-description {
            max-width: 700px;
            margin: 0 auto;
            color: var(--text-muted);
            font-size: 1.08rem;
            line-height: 1.9;
        }

        .home-page .hero-actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 35px;
        }

        .home-page .hero-actions .action-btn {
            min-width: 210px;
            min-height: 53px;
        }

        .home-page .arrow {
            display: inline-block;
            transition: transform 0.25s ease;
        }

        .home-page .action-btn:hover .arrow {
            transform: translateX(4px);
        }

        .home-page .hero-note {
            margin-top: 24px;
            color: var(--text-muted);
            font-size: 0.84rem;
        }

        /* Feature cards */

        .home-page .features {
            max-width: 1100px;
            margin: 0 auto;
            padding: 10px 25px 95px;
        }

        .home-page .section-heading {
            margin-bottom: 28px;
            text-align: center;
            animation: heroReveal 0.8s ease both;
        }

        .home-page .section-heading h2 {
            margin: 0 0 10px;
            color: var(--text-main);
            font-size: clamp(1.7rem, 3vw, 2.25rem);
            letter-spacing: -0.7px;
        }

        .home-page .section-heading p {
            margin: 0;
            color: var(--text-muted);
            line-height: 1.7;
        }

        .home-page .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .home-page .feature-card {
            position: relative;
            overflow: hidden;
            padding: 28px 25px;
            border: 1px solid var(--border-color);
            border-radius: 17px;
            background: var(--card-bg);
            backdrop-filter: blur(12px);
            transition:
                transform 0.35s ease,
                border-color 0.35s ease,
                box-shadow 0.35s ease;
            animation: cardReveal 0.7s ease both;
        }

        .home-page .feature-card:nth-child(2) {
            animation-delay: 0.12s;
        }

        .home-page .feature-card:nth-child(3) {
            animation-delay: 0.24s;
        }

        .home-page .feature-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(
                90deg,
                var(--primary-accent),
                var(--secondary-accent)
            );
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.35s ease;
        }

        .home-page .feature-card:hover {
            transform: translateY(-8px);
            border-color: rgba(124, 58, 237, 0.65);
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.22);
        }

        .home-page .feature-card:hover::before {
            transform: scaleX(1);
        }

        .home-page .feature-icon {
            width: 51px;
            height: 51px;
            display: grid;
            place-items: center;
            margin-bottom: 20px;
            border: 1px solid rgba(124, 58, 237, 0.25);
            border-radius: 14px;
            background: rgba(124, 58, 237, 0.12);
            font-size: 23px;
            transition: transform 0.35s ease;
        }

        .home-page .feature-card:hover .feature-icon {
            transform: translateY(-3px) rotate(-5deg) scale(1.06);
        }

        .home-page .feature-card h3 {
            margin: 0 0 11px;
            color: var(--text-main);
            font-size: 1.12rem;
        }

        .home-page .feature-card p {
            margin: 0;
            color: var(--text-muted);
            font-size: 0.93rem;
            line-height: 1.8;
        }

        /* Footer */

        .home-page .site-footer {
            padding: 24px;
            border-top: 1px solid rgba(38, 50, 71, 0.75);
            color: var(--text-muted);
            text-align: center;
            font-size: 0.85rem;
        }

        .home-page .site-footer span {
            color: var(--text-main);
            font-weight: 700;
        }

        /* Animations */

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-18px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes heroReveal {
            from {
                opacity: 0;
                transform: translateY(25px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes cardReveal {
            from {
                opacity: 0;
                transform: translateY(18px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes gradientFlow {
            from { background-position: 0% center; }
            to { background-position: 100% center; }
        }

        @keyframes ambientFloat {
            from { transform: translate(0, 0) scale(1); }
            to { transform: translate(45px, -30px) scale(1.12); }
        }

        @keyframes dotPulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.45; }
        }

        /* Responsive layout */

        @media (max-width: 760px) {
            .home-page .site-nav {
                padding: 20px;
            }

            .home-page .brand-name {
                font-size: 1.25rem;
                letter-spacing: 1px;
            }

            .home-page .brand-icon {
                width: 38px;
                height: 38px;
            }

            .home-page .nav-actions {
                gap: 8px;
            }

            .home-page .nav-actions .action-btn {
                min-height: 40px;
                padding: 9px 13px;
                font-size: 0.84rem;
            }

            .home-page .hero {
                padding: 75px 22px 65px;
            }

            .home-page .hero h1 {
                letter-spacing: -1.5px;
            }

            .home-page .hero-description {
                font-size: 1rem;
            }

            .home-page .feature-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 480px) {
            .home-page .site-nav {
                padding: 17px 15px;
                gap: 10px;
            }

            .home-page .brand {
                gap: 8px;
            }

            .home-page .brand-name {
                font-size: 1.05rem;
                letter-spacing: 0.5px;
            }

            .home-page .brand-icon {
                width: 33px;
                height: 33px;
                border-radius: 10px;
                font-size: 18px;
            }

            .home-page .nav-actions .action-btn {
                padding: 8px 10px;
                font-size: 0.78rem;
            }

            .home-page .hero {
                padding: 65px 18px 55px;
            }

            .home-page .eyebrow {
                font-size: 0.64rem;
                letter-spacing: 0.8px;
                padding: 9px 12px;
            }

            .home-page .hero h1 {
                font-size: clamp(2.2rem, 10vw, 3rem);
                letter-spacing: -1.2px;
            }

            .home-page .hero-actions {
                flex-direction: column;
                align-items: stretch;
            }

            .home-page .hero-actions .action-btn {
                width: 100%;
                min-width: 0;
            }

            .home-page .features {
                padding: 10px 18px 65px;
            }

            .home-page .feature-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .home-page .feature-card {
                padding: 24px;
            }
        }

        /* Accessibility: respect reduced-motion preferences */

        @media (prefers-reduced-motion: reduce) {
            .home-page *,
            .home-page *::before,
            .home-page *::after {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                scroll-behavior: auto !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>

<body>
<div class="home-page">

    <div class="ambient ambient-purple"></div>
    <div class="ambient ambient-blue"></div>

    <nav class="site-nav">
        <a href="index.php" class="brand" aria-label="INTERNOVA Home">
            <span class="brand-icon">I</span>
            <span class="brand-name">INTERNOVA</span>
        </a>

        <div class="nav-actions">
            <a href="login.php" class="action-btn btn-outline">
                Login
            </a>

            <a href="register.php" class="action-btn btn-primary">
                Get Started <span class="arrow">→</span>
            </a>
        </div>
    </nav>

    <header class="hero">
        <div class="hero-content">

            <div class="eyebrow">
                <span class="status-dot"></span>
                Next-Gen Internship Ecosystem
            </div>

            <h1>
                Where Future Talent Meets
                <br>
                <span class="gradient-text">Industry Leaders</span>
            </h1>

            <p class="hero-description">
                Turn your potential into real-world experience.
                Discover exciting internship opportunities, showcase
                your skills, and connect with companies ready to invest
                in tomorrow's talent.
            </p>

            <div class="hero-actions">
                <a href="register.php?role=student"
                   class="action-btn btn-primary">
                    Explore as Student
                    <span class="arrow">→</span>
                </a>

                <a href="register.php?role=company"
                   class="action-btn btn-outline">
                    Post Internships
                    <span class="arrow">↗</span>
                </a>
            </div>

            <p class="hero-note">
                Built for ambitious students and forward-thinking companies.
            </p>

        </div>
    </header>

    <section class="features">
        <div class="section-heading">
            <h2>Your Next Opportunity Starts Here</h2>
            <p>Everything you need to take the next step in your career.</p>
        </div>

        <div class="feature-grid">

            <article class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3>Discover Opportunities</h3>
                <p>
                    Explore internship opportunities that help you
                    develop practical skills and gain industry experience.
                </p>
            </article>

            <article class="feature-card">
                <div class="feature-icon">🚀</div>
                <h3>Build Your Career</h3>
                <p>
                    Create your profile, showcase your strengths,
                    and manage your internship applications in one place.
                </p>
            </article>

            <article class="feature-card">
                <div class="feature-icon">🤝</div>
                <h3>Connect with Talent</h3>
                <p>
                    Help companies discover aspiring professionals
                    and manage internship applicants efficiently.
                </p>
            </article>

        </div>
    </section>

    <footer class="site-footer">
        © 2026 <span>INTERNOVA</span>. Launch your career orbit.
    </footer>

</div>
</body>
</html>